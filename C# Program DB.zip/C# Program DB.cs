﻿
using (SqlConnection connection = new SqlConnection(connectionString))
{
    connection.Open();
    using (SqlCommand command = new SqlCommand("SELECT FileData FROM Files WHERE FileId = @FileId", connection))
    {
        command.Parameters.AddWithValue("@FileId", fileId);
        using (SqlDataReader reader = command.ExecuteReader())
        {
            if (reader.Read())
            {
                byte[] fileData = (byte[])reader["FileData"];
                using (MemoryStream stream = new MemoryStream(fileData))
                {
                    Google.Apis.Drive.v3.DriveService driveService = new Google.Apis.Drive.v3.DriveService(new Google.Apis.Auth.OAuth2.GoogleCredential());
                    Google.Apis.Drive.v3.FilesResource.CreateMediaUpload request = driveService.Files.Create(new Google.Apis.Drive.v3.Data.File(), stream, "application/octet-stream");
                    request.Fields = "id";
                    request.Upload();
                }
            }
        }
    }
}
